//
//  Enemy.swift
//  MyFirstApp
//
//  Created by MacStudent on 2019-05-28.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import Foundation
import UIKit

class Enemy : UIImageView {
    
    var health: Int
    var speed: CGFloat
    var img: UIImage
    var destination: CGPoint = CGPoint(x: 0, y: 0)
    var t: Timer?
     var bulletTimer: Timer?
    
  let bullet = UIImageView(image: UIImage(named: "bullet.png"))
    
    
    init(hlt: Int, spd: CGFloat, shp: UIImage, initialPosition: CGPoint)
    {
        self.health = hlt
        self.speed = spd
        self.img = shp
        super.init(image: shp)
        self.frame = CGRect(x: initialPosition.x, y: initialPosition.y, width: 75, height: 100)
        
        
        let swipe = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction))
        self.addGestureRecognizer(swipe)
//
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapAction))
        self.addGestureRecognizer(tap)

        self.isUserInteractionEnabled = true
        

    
    }

    @objc func tapAction()
    {
        
        //Shoot horizontaaly
        
        bullet.frame = CGRect(x: 70, y: 0, width: 30, height: 20)
        self.addSubview(bullet)
        bulletTimer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(animateBullet), userInfo: nil, repeats: true)
        
    }
    @objc func swipeAction()
    {
        self.removeFromSuperview()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    func trackTap(dest: CGPoint)
    {
        let spd = 1/self.speed
        self.destination = dest
        t = Timer.scheduledTimer(timeInterval: TimeInterval(spd), target: self, selector: #selector(animate), userInfo:nil, repeats: true)
    }
    
    @objc func animate()
    {
        let myPosition = self.frame.origin
        
        let f = CGVector(dx: (destination.x - myPosition.x), dy: (destination.y - myPosition.y))
        
        let distance_to_target = sqrt(pow((destination.x - myPosition.x), 2) + pow((destination.y - myPosition.y), 2))
        
        let u = CGVector(dx: f.dx/distance_to_target, dy: f.dy/distance_to_target)
        
        self.frame.origin.x += u.dx
        self.frame.origin.y += u.dy
        
        if (distance_to_target < 2) {
            t?.invalidate()
        }
    }
    
    
    @objc func animateBullet()
    {
        let bounds: CGRect = UIScreen.main.bounds
        let width:CGFloat = bounds.size.width
        let height:CGFloat = bounds.size.height
        self.bullet.frame.origin.x += 3
        if (self.bullet.frame.origin.x > width)
        {
            bulletTimer?.invalidate()
            self.bullet.removeFromSuperview()
        }
    
        
      
    }
    
}


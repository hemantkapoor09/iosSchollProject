//
//  ViewController.swift
//  MyFirstApp
//
//  Created by MacStudent on 2019-05-25.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit

class ViewController:
UIViewController {
   
    var counter = 1
  
    var t: Timer?
    
    var movingDirection = 1
    
     var enemyArray = [Enemy]()

   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        

                let tap = UITapGestureRecognizer(target: self, action: #selector(attackToLocation))
                self.view.addGestureRecognizer(tap)
//        let swipe = UISwipeGestureRecognizer(target: self, action: #selector(killEveryOne))
//        self.view.addGestureRecognizer(swipe)
        //        self.view.isUserInteractionEnabled = true

                        //        let pan = UIPanGestureRecognizer(target: self, action: #selector(panAction))
                        //        self.view.addGestureRecognizer(pan)
            let speed = arc4random_uniform(50) + 100
            let tmp = Enemy(hlt: 100, spd: CGFloat(speed), shp: UIImage(named: "frame-1.png")!, initialPosition: CGPoint(x: CGFloat(60), y: CGFloat(100)))
            enemyArray.append(tmp)
            self.view.addSubview(tmp)
    
        
       
       
    }
    
    @objc func attackToLocation(touch: UITapGestureRecognizer)
    {
       
        let touchPoint = touch.location(in: self.view)
        let speed = arc4random_uniform(50) + 100
        let tmp = Enemy(hlt: 100, spd: CGFloat(speed), shp: UIImage(named: "frame-1.png")!, initialPosition: CGPoint(x: CGFloat(touchPoint.x), y: CGFloat(touchPoint.y)))
        enemyArray.append(tmp)
        self.view.addSubview(tmp)

    }
    
//    @objc func killEveryOne(swipe: UISwipeGestureRecognizer)
//    {
//        for i in 0...enemyArray.count
//        {
//            enemyArray[i].removeFromSuperview()
//        }
//    }
//
    


}


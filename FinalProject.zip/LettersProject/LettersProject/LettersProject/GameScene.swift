//
//  GameScene.swift
//  LettersProject
//
//  Created by HemAnt on 2019-06-07.
//  Copyright © 2019 HemAnt. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    
  private var label : SKLabelNode?
  private var spinnyNode : SKShapeNode?
  var box1: SKSpriteNode?
  var box2: SKSpriteNode?
  var box3: SKSpriteNode?
  var scoreLabel: SKLabelNode?
  var score: Int = 0
  var coinNumber: Int = 1
  var coin: SKSpriteNode?
  
  let box1Category: UInt32 = 0x1 << 1 //=1
  let coinCategory: UInt32 = 0x1 << 4 //=2
  let box2Category: UInt32 = 0x1 << 2 //=2
  let box3Category: UInt32 = 0x1 << 3 //=2
  var coinTimer: Timer?
    
  override func didMove(to view: SKView) {
    scoreLabel = childNode(withName: "scoreLabel") as? SKLabelNode
    backgroundColor = SKColor.white
    let box1 = SKSpriteNode(imageNamed: "basket3.png")
    box1.size = CGSize(width: size.width/3, height: size.width/3)
    box1.position = CGPoint(x: -size.width/3, y: -((size.height/2)-115))
    box1.physicsBody?.categoryBitMask = box1Category
    box1.physicsBody?.contactTestBitMask = coinCategory
    addChild(box1)
    let box2 = SKSpriteNode(imageNamed: "basket3.png")
    box2.size = CGSize(width: size.width/3, height: size.width/3)
    box2.position = CGPoint(x: 0, y: -((size.height/2)-115))
    box2.physicsBody?.categoryBitMask = box2Category
    box2.physicsBody?.contactTestBitMask = coinCategory
    addChild(box2)
    let box3 = SKSpriteNode(imageNamed: "basket3.png")
    box3.size = CGSize(width: size.width/3, height: size.width/3)
    box3.position = CGPoint(x: size.width/3, y: -((size.height/2)-115))
    box3.physicsBody?.categoryBitMask = box3Category
    box3.physicsBody?.contactTestBitMask = coinCategory
    addChild(box3)
    physicsWorld.contactDelegate = self
    coinTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: {(timer) in self.createCoin()})
  }
  
  func createCoin() {
    coin = SKSpriteNode(imageNamed: "img-\(Int(arc4random_uniform(UInt32(8))))")
    coin!.size = CGSize(width: 100, height: 100)
    coin!.physicsBody = SKPhysicsBody(rectangleOf: coin!.size)
    coin!.physicsBody?.affectedByGravity = false
    coin!.physicsBody?.categoryBitMask = coinCategory
    coin!.physicsBody?.contactTestBitMask = box1Category
    coin!.physicsBody?.contactTestBitMask = box2Category
    coin!.physicsBody?.contactTestBitMask = box3Category
    addChild(coin!)
    let maxX = size.width/2 - coin!.size.width / 2
    let minX = -size.width/2 + coin!.size.width / 2
    let range = maxX - minX
    let coinX = maxX - CGFloat(arc4random_uniform(UInt32(range)))
    coin!.position = CGPoint(x: coinX, y: size.height/2 - coin!.size.height/2)
    let moveDown = SKAction.moveBy(x: 0, y: -(size.height + coin!.size.width - size.width/3), duration: 6)
    let mySeq = SKAction.sequence([moveDown, SKAction.removeFromParent()])
    coin!.run(mySeq)
  }
}

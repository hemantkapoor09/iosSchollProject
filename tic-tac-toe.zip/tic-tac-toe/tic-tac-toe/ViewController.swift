//
//  ViewController.swift
//  tic-tac-toe
//
//  Created by MacStudent on 2019-06-08.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    var x_turn: Bool = true
    var gameOver: Bool = false
    
    var board = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    
    var winning_condition = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6],[1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnPressed(_ sender: AnyObject) {
        print("Clicked!!!")
        if (x_turn && !gameOver){
            (sender as AnyObject).setImage(UIImage(named: "X.png"), for: [])
            x_turn = false
            board[sender.tag - 1] = 1
        }
        else if(!x_turn && !gameOver)
        {
            (sender as AnyObject).setImage(UIImage(named: "O.png"), for: [])
            x_turn = true
            board[sender.tag - 1] = 2
        }
        
        
        for win_cond in winning_condition {
            
            if (board[win_cond[0]] != 0 && board[win_cond[0]] == board[win_cond[1]] && board[win_cond[1]] == board[win_cond[2]]){
                
                gameOver = true
                print("Game Over")
            }
            
        }
        
        print(board)
        
    }
    
    func placeOnBoard(){
        if (x_turn){
            //Place X on board
        }
        else if (!x_turn)
        {
            //Place O on board
        }
        
    }
    
    

}


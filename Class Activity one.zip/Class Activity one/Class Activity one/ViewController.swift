//
//  ViewController.swift
//  Class Activity one
//
//  Created by MacStudent on 2019-06-18.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {
    
    
    var pId: Int32 = 0
    var pscore: Float = 0
    var pscoreAll:String = ""
    var topScore: [Float] = []
    @IBOutlet weak var scores: UITextView!
    @IBOutlet weak var high_Scores: UITextView!
    @IBOutlet weak var add: UIButton!
    @IBOutlet weak var playerId: UITextField!
    @IBOutlet weak var score: UITextField!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
   
    }

    @IBAction func addScore(_ sender: Any) {
        var flag = false
        if((score.text!) != nil)
        {
            pscore = Float(score.text!)!
            flag = true
        }
        
        if((playerId.text!) != nil){
            pId = (Int32(playerId.text!)!)
            flag = true
        }
        
        if(flag == true){
            var newLine: String = "\n Player Id: \(pId) \t Score:\(pscore) \n"
            pscoreAll.append(newLine)
        }
        
        updateScore()
        fetch()
        
    }
    
    func updateScore(){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Player", in: context)
        let newPlayer = NSManagedObject(entity: entity!, insertInto: context)
            newPlayer.setValue(pId, forKey: "playerId")
            newPlayer.setValue(pscore, forKey: "score")
        
        do {
            try context.save()
        } catch {
            print("Failed saving")
        }
        
        
        scores.text = (pscoreAll)
        
    }
    
    func fetch(){
       
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Player")
        //request.predicate = NSPredicate(format: "age = %@", "12")
//        request.returnsObjectsAsFaults = false
        do {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject] {
            
                var temp:Float = (data.value(forKey: "score") as! Float)
                topScore.append(temp)
//                print(data.value(forKey: "playerId") as! String)
            }
            
        } catch {
            
            print("Failed")
        }
        
        var array = topScore
        var st:String = "Top Scores:"
        array.sort(by: >)
        
        if(array.count > 2)
        {
            guard let temp = (array.first) else {return}
            st.append("\n 1: \(temp) \n 2: \(array[1]) \n 3: \(array[2])")
            
            if let index = array.index(of: temp) {
                    array.remove(at: index)
                    array.remove(at: (index + 1))
                
            }
        }
        high_Scores.text = (st)
    }
}


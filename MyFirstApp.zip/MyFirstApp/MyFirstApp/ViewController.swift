//
//  ViewController.swift
//  MyFirstApp
//
//  Created by MacStudent on 2019-05-25.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit

class ViewController:
UIViewController {

    @IBOutlet weak var txtbx: UITextField!
    
    @IBOutlet weak var sldr: UISlider!
    
    @IBOutlet weak var btn: UIButton!
    
    @IBOutlet weak var imgBox: UIImageView!
    
    var counter = 1
    
    var t: Timer?
    
    var movingDirection = 1
    
    @IBAction func sliderResponse(_ sender: Any) {
        
        txtbx.text = String(sldr.value)
    } 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        btn.setTitle("Animate", for: .normal)
        
        imgBox.image = UIImage(named: "frame-2.png")
    }
    
    @IBAction func btnAction(_ sender: Any) {
        
        t = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(imageSwaper), userInfo: nil, repeats: true)
    }
    
    @objc func imageSwaper()
    {
       imgBox.image = UIImage(named: "frame-\(counter).png")
        counter += 1
        if (counter == 4){
            counter = 1
        }
        
        imgBox.frame.origin.x += CGFloat(5 * movingDirection)
        imgBox.frame.origin.y += CGFloat(5 * movingDirection)
        let bounds: CGRect = UIScreen.main.bounds
        let width:CGFloat = bounds.size.width
        let height:CGFloat = bounds.size.height
        
        if (imgBox.frame.origin.x > width - 200 && imgBox.frame.origin.y > height - 600 )
        {
            //t?.invalidate()
            print(imgBox.frame.origin.x)
            print(imgBox.frame.origin.y)
            movingDirection = -1
        }
        if (imgBox.frame.origin.x < 50 && imgBox.frame.origin.y < 200)
        {
            
            print(imgBox.frame.origin.x)
            print(imgBox.frame.origin.y)
            movingDirection = 1
        }
    }
    
    
    
    


}


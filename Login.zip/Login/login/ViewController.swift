//
//  ViewController.swift
//  login
//
//  Created by MacStudent on 2019-06-22.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
   
    @IBOutlet weak var signIn: UIButton!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var signUp: UIButton!
    var msgStr = ""
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     signUp.isHidden = true
    }

    
  
    @IBAction func signIn(_ sender: Any) {
        checkUser()
       
    }
    
    
    @IBAction func signUp(_ sender: Any) {
    }
    
  
    func checkUser(){
        //To fetch data from database
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Credentials")
        request.returnsObjectsAsFaults = false
        
//        request.predicate = NSPredicate(format: "studentid == %@" , "111111")
        
        do {
            
            let results = try context.fetch(request)
            
            for elem in results as! [NSManagedObject] {
                
                 var pass = elem.value(forKey: "password") as? String
                 var uname = elem.value(forKey: "username") as? String
                if(uname == "\(username.text!)" && pass == "\(password.text!)"){
                   
                    signUp.isHidden = true
                    signIn.isHidden = false
                    msgStr = "Hello \(username.text!)"
                    let alertController = UIAlertController(title: "Hemant", message:
                        "\(msgStr)", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
                    
                    self.present(alertController, animated: true, completion: nil)
                    print("Sucess Login")
                }
                else{
                    signIn.isHidden = true
                    let alertController = UIAlertController(title: "Hemant", message:
                        "User Dosent Exists with These Credentials", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
                    
                    self.present(alertController, animated: true, completion: nil)
                    signUp.isHidden = false
                    
                    signIn.addTarget(self, action: #selector(self.signUp(_:)), for: .touchUpInside)
                }
            }
            
            
            
            
        }
        catch{
            print("Query failed")
        }

    }
}

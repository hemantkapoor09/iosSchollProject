//
//  SignUp.swift
//  login
//
//  Created by MacStudent on 2019-06-22.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit
import CoreData
class SignUp: UIViewController {

    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var adress: UITextField!
    @IBOutlet weak var age: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    
    }
    
    @IBAction func signUp(_ sender: Any) {
        newUser()
 
        //        performSegue(withIdentifier: "signIn", sender: self)
         sleep(1)  
        
    }
    
    func newUser(){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let newPerson = NSEntityDescription.insertNewObject(forEntityName: "Credentials", into: context)
        var ag:Int32 = Int32(age.text!) ?? 0
        newPerson.setValue("\(username.text!)", forKey: "username")
        newPerson.setValue("\(password.text!)", forKey: "password")
        newPerson.setValue(ag, forKey: "age")
        newPerson.setValue("\(adress.text!)", forKey: "adress")
        
        do{
            try context.save()
            let alertController = UIAlertController(title: "Hemant", message:
                "Register Sucessfully", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
            
            self.present(alertController, animated: true, completion: nil)
            
            print("Go To Login")
        }
        catch{
            print("I/O Failed...")
        }
        sleep(1)
    }
    
   

}

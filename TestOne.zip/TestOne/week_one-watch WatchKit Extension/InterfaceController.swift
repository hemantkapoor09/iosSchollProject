//
//  InterfaceController.swift
//  week_one-watch WatchKit Extension
//
//  Created by MacStudent on 2019-06-14.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
//    var firstName = "Alex"
//    var lastName = "Robert"
//    var age = 32
//    var sex = "Male"
//    var phone = "+1 416-454-7878"
//    var address = " 256 Yorkland Blvd"
//    let  docEmail = "assignment4@cmycollege.com"
//
//    var heartRate:[UInt32] = []
//    var day = 0
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
   
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
       
//        heartRate = UserDefaults.standard.array(forKey: "heartRateArray") as! [UInt32]
       
//
//        for _ in 1...5{
//
//            //generate randomvalues and add them to the array
//            let lower : UInt32 = 80
//            let upper : UInt32 = 150
//            let heartRateValue = arc4random_uniform(upper - lower) + lower
//            heartRate.append(heartRateValue)
//
//        }
//
//
//        //To store array in the memory of device
//        UserDefaults.standard.set(heartRate, forKey: "heartRateArray")
//        UserDefaults.standard.synchronize()
//
//        //To retreive and print the values
//        var htrt = UserDefaults.standard.array(forKey: "heartRateArray")
//        sendDataToDoc(htrt: htrt as! [UInt32])
//
//
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
        
    }
    
//    func sendDataToDoc(htrt:[UInt32]){
//        day += 1
//
////        var temp = htrt
////        temp.sort()
////
////        let avg = temp[2]
//        var avg:UInt32 = 0
//
//
//        for i in 0...4
//        {
//            avg += htrt[i]
//        }
//        avg = (avg / 5)
//
//        var str = "Heatrate Report for Patient \n \t First Name : \(firstName) \n \t Last Name : \(lastName) \n \t Sex : \(sex) \n \t Phone Number : \(phone) \n \t Address : \(address) \n For Day [\(day)] : \(htrt) \t <> With Aversge Of >> \(avg)"
//
//        print(str)
//    }
}

//
//  ViewController.swift
//  week_one-watch
//
//  Created by MacStudent on 2019-06-14.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit
import MessageUI

class ViewController: UIViewController, MFMailComposeViewControllerDelegate  {

    @IBOutlet weak var frstname: UITextField!
    @IBOutlet weak var lastname: UITextField!
    @IBOutlet weak var sex: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var adress: UITextField!
    @IBOutlet weak var mailToDoc: UITextView!
    @IBOutlet weak var sendMail: UIButton!
    

    let  docEmail = "assignment4@cmycollege.com"
    
    var heartRate:[UInt32] = []
    var day = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        sendMail.isHidden = true
        
    }
    func sendDataToDoc(htrt:[UInt32]){
        day += 1
        
        //        var temp = htrt
        //        temp.sort()
        //
        //        let avg = temp[2]
        var avg:UInt32 = 0
        
        
        for i in 0...4
        {
            avg += htrt[i]
        }
        avg = (avg / 5)
        
        var str = "Heatrate Report for Patient \n \t First Name : \(frstname.text!) \n \t Last Name : \(lastname.text!) \n \t Sex : \(sex.text!) \n \t Phone Number : \(phone.text!) \n \t Address : \(adress.text!) \n For Day [\(day)] : \(htrt) \n\t\t\t  ~ With Aversge Of : \(avg)"
        
        mailToDoc.text = str
        sendMail.isHidden = false
//        print(str)
    }
    
    @IBAction func rememberMe(_ sender: Any) {
        for _ in 1...5{
            
            //generate randomvalues and add them to the array
            let lower : UInt32 = 80
            let upper : UInt32 = 150
            let heartRateValue = arc4random_uniform(upper - lower) + lower
            heartRate.append(heartRateValue)
            
        }
        
        
        //To store array in the memory of device
        UserDefaults.standard.set(heartRate, forKey: "heartRateArray")
        UserDefaults.standard.synchronize()
        
        //To retreive and print the values
        var htrt = UserDefaults.standard.array(forKey: "heartRateArray")
        sendDataToDoc(htrt: htrt as! [UInt32])
        
        
    }
    @IBAction func sendMail(_ sender: Any) {
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients([docEmail])
            mail.setSubject("Report")
            mail.setMessageBody("<b>\(mailToDoc.text!)</b>", isHTML: true)
            present(mail, animated: true, completion: nil)
        } else {
            print("Error: Can't Send Mail Because You Are not Logged-In in your Mail App ")
            // give feedback to the user
        }
        
        func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
            switch result.rawValue {
            case MFMailComposeResult.cancelled.rawValue:
                print("Cancelled")
            case MFMailComposeResult.saved.rawValue:
                print("Saved")
            case MFMailComposeResult.sent.rawValue:
                print("Sent")
            case MFMailComposeResult.failed.rawValue:
                print("Error: \(String(describing: error?.localizedDescription))")
            default:
                break
            }
            controller.dismiss(animated: true)
        }
    }
    
  
    
    
}

